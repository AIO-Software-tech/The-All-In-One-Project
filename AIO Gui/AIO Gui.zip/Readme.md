This is the files for the GUI version off aio
This is still in alpha so it does not have all the feachers of AIO
