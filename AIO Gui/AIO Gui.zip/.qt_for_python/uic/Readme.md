The .py files for aio gui
